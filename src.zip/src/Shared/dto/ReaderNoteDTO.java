package Shared.dto;

public class ReaderNoteDTO
{
}
