package Shared.util;

public class SerializationUtils
{
}
