package Client.view;


import Client.viewmodel.UserProfileVM;
import javafx.scene.control.Label;

public class UserInfoController {
//  public Label lblUserName, lblFullName, lblEmail, lblPhoneNumber, lblAddress;
//  private UserProfileVM vm;
//
//  public void initialize() {
//    // inject the same service you used for login:
//    AuthServiceClient svc = new SocketAuthServiceClient();
//    vm = new UserProfileVM(svc);
//
//    // bind labels to VM properties
//    lblUserName.textProperty().bind(vm.userName);
//    lblFullName.textProperty().bind(vm.fullName);
//    lblEmail.textProperty().bind(vm.email);
//    lblPhoneNumber.textProperty().bind(vm.phoneNumber);
//    lblAddress.textProperty().bind(vm.address);
//  }
//
//  public void onPageShow(String username) throws Exception
//  {
//    vm.loadUserInfo(username);
//  }
}
