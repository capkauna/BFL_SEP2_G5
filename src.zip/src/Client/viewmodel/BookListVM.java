package Client.viewmodel;

public class BookListVM
{

  private String username;

  public BookListVM(String username)
  {
    this.username = username;
  }
}
