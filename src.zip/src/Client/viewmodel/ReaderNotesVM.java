package Client.viewmodel;

public class ReaderNotesVM
{
  private String currentuser;

  public ReaderNotesVM(String currentuser)
  {
    this.currentuser = currentuser;
  }
}
