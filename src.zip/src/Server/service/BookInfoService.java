package Server.service;

import Server.database.JdbcBookDAO;
import Server.model.Book;
import Server.model.User;
import Shared.dto.enums.Genre;

import java.sql.SQLException;
import java.util.List;

public class BookInfoService
{
  private final JdbcBookDAO books;
  public BookInfoService() throws SQLException
  {
    this.books = JdbcBookDAO.getInstance();
  }

  public Book getBookInfo(int bookId) throws SQLException
  {
    return books.findById(bookId);
  }
  public List<Book> getAllBooks() throws SQLException
  {
    return books.findAll();
  }
  public List<Book> getBooksByTitle(String title) throws SQLException
  {
    return books.findByTitle(title);
  }
  public List<Book> getBooksByAuthor(String author) throws SQLException
  {
    return books.findByAuthor(author);
  }
  public List<Book> getBooksByGenre(Genre genre) throws SQLException
  {
    return books.findByGenre(genre);
  }
  public List<Book> getBorrowedBooksBy(User u) throws SQLException
  {
    return books.findByBorrowedBy(u);
  }
  public List<Book> getBooksByOwner(User u) throws SQLException
  {
    return books.findByOwner(u);
  }

}
